"use client";

import AppProfile from "@/components/profile/app-profile";
import React from "react";

const Page: React.FC = () => {

  return <AppProfile />;
};

export default Page;
