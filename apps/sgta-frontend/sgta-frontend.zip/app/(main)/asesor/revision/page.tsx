"use client";

import RevisionAsesorPage from "@/features/revision/views/revision-asesor-page";
import React from "react";

const Page: React.FC = () => {
  return <RevisionAsesorPage />;
};

export default Page;
