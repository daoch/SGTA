"use client";

const Page: React.FC = () => {
  return <div>page</div>;
};

export default Page;
