import PropuestasAsesorPage from "@/features/temas/views/propuestas-asesor-page";
import React from "react";

const Page: React.FC = () => {
  return <PropuestasAsesorPage />;
};

export default Page;
