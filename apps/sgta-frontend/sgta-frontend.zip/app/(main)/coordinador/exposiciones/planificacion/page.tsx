import PlanExpo from "@/features/jurado/views/PlanExpo";

export default async function Page (){
    return <PlanExpo exposicionId={0}></PlanExpo>;
}