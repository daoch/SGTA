"use client";

import { ExposicionesCoordinadorPage } from "@/features/jurado/views/exposiciones-coordinador-page";
import React from "react";

const Page: React.FC = () => {
  return <ExposicionesCoordinadorPage />;
};

export default Page;
