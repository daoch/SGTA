"use client";

import TemasCoordinadorPage from "@/features/temas/views/temas-coordinador-page";
import React from "react";

const Page: React.FC = () => {
  return <TemasCoordinadorPage />;
};

export default Page;
