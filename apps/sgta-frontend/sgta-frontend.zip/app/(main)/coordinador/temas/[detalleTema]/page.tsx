"use client";

import DetalleTemasCoordinadorPage from "@/features/temas/views/detalle-temas-coordinador-page";
import React from "react";

const Page: React.FC = () => {
  return <DetalleTemasCoordinadorPage />;
};

export default Page;
