import React from "react";

const Page: React.FC = () => {
  return <div>page</div>;
};

export default Page;
