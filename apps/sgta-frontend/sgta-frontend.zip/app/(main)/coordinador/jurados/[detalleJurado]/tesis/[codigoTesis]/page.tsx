"use client";
import { DetalleTesisJuradoView } from "@/features/jurado/views/DetalleTesisJurado";

export default function TesisDetallePage() {
  return <DetalleTesisJuradoView />;
}
