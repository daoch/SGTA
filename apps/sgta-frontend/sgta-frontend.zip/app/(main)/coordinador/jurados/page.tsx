"use client";

import JuradosView from "@/features/jurado/views/CoordinadorJuradoPage";

export default function JuradosPage() {
  return <JuradosView />;
}
