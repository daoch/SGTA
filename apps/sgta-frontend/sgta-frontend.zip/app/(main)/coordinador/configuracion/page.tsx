"use client";

import Configuracion from "@/features/configuracion/views/Configuracion";
import React from "react";

const Page: React.FC = () => {
  return <Configuracion />;
};

export default Page;
