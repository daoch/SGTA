"use client";

import ConfiguracionSistema from "@/features/configuracion/views/ConfiguracionSistema";
import React from "react";

const Page: React.FC = () => {
  return <ConfiguracionSistema />;
};

export default Page;
