"use client";

import ExposicionesJuradoPage from "@/features/jurado/views/vista-exposiciones/exposiciones-jurado-page";
import React from "react";

const Page: React.FC = () => {
  return <ExposicionesJuradoPage />;
};

export default Page;
