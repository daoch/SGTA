"use client";

import Exposiciones from "@/features/jurado/views/vista-exposiciones/alumno-exposiciones";
import React from "react";

const Page: React.FC = () => {
  return <Exposiciones />;
};

export default Page;
