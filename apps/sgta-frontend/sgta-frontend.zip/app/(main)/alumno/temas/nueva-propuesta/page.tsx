import FormularioPropuestaPage from "@/features/temas/views/formulario-propuesta-alumno-page";
import React from "react";

const Page: React.FC = () => {
  return <FormularioPropuestaPage />;
};

export default Page;
