import MisTemasPage from "@/features/temas/views/temas-alumno-page";
import React from "react";

const Page: React.FC = () => {
  return <MisTemasPage />;
};

export default Page;
