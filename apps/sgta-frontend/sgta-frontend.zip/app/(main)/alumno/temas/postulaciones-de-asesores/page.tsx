import PostulacionesRecibidasPage from "@/features/temas/views/postulaciones-recibidas-alumno-page";
import React from "react";

const Page: React.FC = () => {
  return <PostulacionesRecibidasPage />;
};

export default Page;
