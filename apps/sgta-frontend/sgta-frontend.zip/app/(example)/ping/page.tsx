"use client";

import PingPage from "@/features/example/views/ping-page";
import React from "react";

const Page: React.FC = () => {
  return <PingPage />;
};

export default Page;
