"use client";

import LoginPage from "@/features/auth/views/login-page";
import React from "react";

const Page: React.FC = () => {
  return <LoginPage />;
};

export default Page;
