"use client";

import RegistroUsuariosClient from "@/features/configuracion/components/registro-usuarios/registro-usuario-client";

export default function RegistroUsuarioWrapper() {
  return <RegistroUsuariosClient />;
}
