export interface CriterioExposicion {
  id?: string;
  nombre: string;
  descripcion: string;
  notaMaxima: number;
};
