export interface CriterioEntregable {
  id?: string;
  nombre: string;
  descripcion: string;
  notaMaxima: number;
};
