export interface Exposicion {
  id?: string;
  estadoPlanificacionId: number;
  nombre: string;
  descripcion: string;
};
