import {
  AreaEspecialidad,
  JornadaExposicionSalas,
} from "../types/jurado.types";

import GeneralPlanificationExpo from "@/features/jurado/components/GeneralPlanificationExpo";
import {
  listarBloquesHorariosExposicion,
  listarEstadoPlanificacionPorExposicion,
  listarJornadasExposicionSalas,
  listarTemasCicloActulXEtapaFormativa,
} from "@/features/jurado/services/data";
import { JornadaExposicionDTO } from "../dtos/JornadExposicionDTO";
type Props = {
  exposicionId: number;
 
};
export default async function PlanExpo({ exposicionId }: Props) {
  const expos = await listarTemasCicloActulXEtapaFormativa(exposicionId);
  const jornadasSalas = await listarJornadasExposicionSalas(exposicionId);
  const topics: AreaEspecialidad[] = [];
  const roomAvailList: JornadaExposicionDTO[] =
    jornadasSalas.map(transformarJornada);
  const bloquesList = await listarBloquesHorariosExposicion(exposicionId);
  const estadoPlanificacion = await listarEstadoPlanificacionPorExposicion(exposicionId);
 
console.log(bloquesList);


  return (  
    <main className="h-screen flex flex-col">
      <div className="py-4">
        <h1
          className="text-blue-900 font-bold text-2xl"
          style={{ color: "#042354" }}
        >
          Planificador de exposiciones
        </h1>
      </div>
      <GeneralPlanificationExpo
        expos={expos}
        topics={topics}
        roomAvailList={roomAvailList}
        bloquesList={bloquesList}
        exposicionId={exposicionId}
        estadoPlanificacion={estadoPlanificacion}
      ></GeneralPlanificationExpo>
    </main>
  );
}

const transformarJornada = (
  data: JornadaExposicionSalas,
): JornadaExposicionDTO => {
  const fechaInicio = new Date(data.datetimeInicio);
  const fechaFin = new Date(data.datetimeFin);

  // De aquí puedes tomar cualquiera de las dos fechas, por ejemplo, `fechaInicio`
  return {
    code: data.jornadaExposicionId, // O cualquier otro campo relevante
    fecha: fechaInicio, // Usamos `dateTimeInicio` como fecha
    horaInicio: fechaInicio.toTimeString().split(" ")[0], // Solo hora
    horaFin: fechaFin.toTimeString().split(" ")[0], // Solo hora
    salasExposicion: data.salasExposicion,
  };
};
