export type EtapaFormativaXSalaExposicion = {
  etapaFormativaXSalaExposicionId: number;
  etapaFormativaId: number;
  salaExposicionId: number;
  nombreSalaExposicion: string;
  nombreEtapaFormativa: string;
};
