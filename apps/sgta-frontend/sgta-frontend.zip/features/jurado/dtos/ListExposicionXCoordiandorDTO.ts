export interface ListExposicionXCoordinadorDTO {
  exposicionId: number;
  nombre: string;
  descripcion: string;
  etapaFormativaId: number;
  etapaFormativaNombre: string;
  cicloId: number;
  cicloNombre: string;
  estadoPlanificacionId: number;
  estadoPlanificacionNombre: string;
}
