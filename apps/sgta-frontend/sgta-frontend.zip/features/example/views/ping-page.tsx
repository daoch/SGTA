"use client";

import SimplePing from "../components/simple-ping";

export default function PingPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <SimplePing />
    </div>
  );
}
